<?php
// =========================================================
//  神龙安全护盾 官网（开源版）
//  纯 PHP 单页，手机自适应，可直接丢进虚拟主机
//  可对接你自己的后台：公告 / 版本号 / 下载地址改数据库读取
// =========================================================

// —— 以下为演示文本，可替换为从数据库读取 ——
$notice  = "公告：神龙安全护盾 2.2 版本已发布\n内置广告 & 恶意 system service 病毒库，支持 Shizuku 授权防护\n科技不再是高高在上，而是服务于人民";
$version = "V2.2";
$downloadUrl = "https://你的域名/apk/slsdapp.apk";
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>神龙安全护盾 官网</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:system-ui}
body{background:#000;color:#fff}
.container{max-width:700px;margin:0 auto;padding:20px}
.logo{text-align:center;margin:30px 0}
.logo-text{font-size:72px;color:#d4af37;font-weight:bold}
.title{text-align:center;font-size:24px;color:#d4af37;margin-bottom:8px}
.subtitle{text-align:center;color:#aaa;margin-bottom:40px}
.card{background:#111;border:1px solid #222;border-radius:14px;padding:24px;margin-bottom:20px}
.card h2{color:#d4af37;margin-bottom:12px;font-size:20px}
.card p{color:#ccc;line-height:1.7}
.download-btn{display:block;text-align:center;background:#d4af37;color:#000;text-decoration:none;padding:16px;border-radius:12px;font-size:18px;font-weight:bold;margin:30px 0}
.ver{text-align:center;color:#d4af37;font-size:16px}
.pop-notice{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);display:flex;align-items:center;justify-content:center;z-index:999}
.pop-box{background:#111;border:1px solid #d4af37;border-radius:16px;padding:24px;max-width:85%;white-space:pre-line}
.pop-box h3{color:#d4af37;margin-bottom:16px;text-align:center}
.close-btn{margin-top:20px;width:100%;padding:12px;background:#d4af37;color:#000;border:none;border-radius:8px;font-size:16px}
.hide{display:none !important}
ul{padding-left:20px;color:#ccc;line-height:1.8}
.update-item{padding:8px 0;border-bottom:#222 solid 1px}
</style>
</head>
<body>
<div class="pop-notice" id="noticePop">
    <div class="pop-box">
        <h3>📢 公告</h3>
        <?php echo $notice; ?>
        <button class="close-btn" onclick="document.getElementById('noticePop').classList.add('hide')">我知道了</button>
    </div>
</div>
<div class="container">
    <div class="logo"><div class="logo-text">龍</div></div>
    <div class="title">神龙安全护盾</div>
    <div class="subtitle">广告拦截 · 恶意程序查杀 · Shizuku 权限防护</div>
    <div class="ver">当前版本 <?php echo $version; ?></div>
    <a class="download-btn" href="<?php echo $downloadUrl; ?>">📥 立即下载 APK</a>
    <div class="card">
        <h2>核心功能</h2>
        <ul>
            <li>广告关键词库拦截（popup、开屏、横幅、激励视频广告）</li>
            <li>System Service 恶意服务病毒检测</li>
            <li>监控 APP 危险权限，识别注入、Hook、劫持行为</li>
            <li>内置 Shizuku 引导界面，仅授权本应用</li>
            <li>云端病毒库实时更新，支持后台下发规则</li>
            <li>设备在线状态上报，后台管理 IP 黑名单</li>
        </ul>
    </div>
    <div class="card">
        <h2>更新日志</h2>
        <div class="update-item">V2.2<br>新增 system service 恶意服务检测规则，扩充 kw/perm 病毒库，修复 Shizuku 获取问题，增加后台设备上报</div>
    </div>
    <div class="card">
        <h2>说明</h2>
        <p>神龙安全护盾，守护安卓设备。科技不再是高高在上，而是服务于人民。</p>
    </div>
</div>
<script>
window.onload=()=>{
    setTimeout(()=>{document.getElementById('noticePop').classList.remove('hide');},300)
}
</script>
</body>
</html>
