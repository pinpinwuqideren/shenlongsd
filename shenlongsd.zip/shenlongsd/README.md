# 神龙安全护盾 (Shenlong Safety Shield)

守护安卓设备 —— 广告拦截 · 恶意程序查杀 · System Service 恶意服务防护 · Shizuku 权限防护

> 科技不再是高高在上，而是服务于人民。

## 项目简介

神龙安全护盾是一款面向 Android 的安全防护工具，核心能力：

- **广告拦截**：内置 2000+ 条广告关键词特征，覆盖开屏、横幅、弹窗、激励视频、原生等主流广告形态
- **恶意程序检测**：基于 kw(关键词) + perm(权限) 双维度特征病毒库，识别注入、Hook、劫持、后台静默安装等恶意行为
- **System Service 恶意服务防护**：检测伪造/劫持/替换系统服务的行为
- **Shizuku 授权防护**：内置 Shizuku 引导界面，仅授权本应用，实现高级权限下的安全防护
- **云端规则更新**：支持后台下发病毒库规则，实时扩充检测能力

## 目录结构

```
shenlongsd/
├── README.md              项目说明
├── LICENSE                开源协议 (MIT)
├── .gitignore             Git 忽略规则
├── virus-database/
│   ├── rules.txt          病毒库规则（kw 关键词 + perm 权限特征，2075 行）
│   └── version.txt        病毒库版本
├── web/
│   └── index.php          官网页面（PHP 单页，手机自适应）
├── apk/
│   └── slsdapp.apk        已编译的 APK 安装包
└── docs/
    └── DEPLOY.md          官网部署说明
```

## 病毒库格式

规则文件 `virus-database/rules.txt` 采用纯文本、每行一条规则的无注释格式：

```
kw:<关键词特征>     # 匹配代码 / 资源中的危险特征关键词
perm:<android权限> # 匹配 APP 申请的敏感权限
```

示例：

```
kw:silentInstall
kw:hook installPackage
perm:android.permission.INSTALL_PACKAGES
perm:android.permission.SYSTEM_ALERT_WINDOW
```

> **声明**：特征库只能识别已收录的已知恶意特征，无法保证拦截 100% 的未知新变种病毒，请勿以"可防御所有病毒"对外宣传。

## 环境依赖

| 组件 | 说明 |
|------|------|
| 应用端 | Android (Kotlin / Material 3)，需配合 Shizuku 获取高级权限 |
| 官网 | PHP 虚拟主机（纯 PHP 单页，无需数据库即可运行） |
| 病毒库 | 纯文本规则，App 启动时读取，支持后台下发更新 |

## 官网部署

见 [docs/DEPLOY.md](docs/DEPLOY.md)。

## 构建与使用

1. 将 `virus-database/` 下的病毒库放入 App 的 `assets/vdb/` 目录
2. 编译安装 `apk/slsdapp.apk`，首次运行按引导完成 Shizuku 授权
3. 病毒库版本通过 `virus-database/version.txt` 管理，App 启动时校验并加载

## 开源协议

本项目采用 [MIT License](LICENSE)。

## 免责声明

本项目仅用于学习与合法的安全防护用途。请勿将病毒库规则用于任何非法、恶意或侵犯他人权益的场景，使用者需自行承担相关法律责任。
