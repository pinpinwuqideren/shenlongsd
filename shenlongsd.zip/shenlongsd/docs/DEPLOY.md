# 神龙安全护盾 · 官网部署说明

官网为纯 PHP 单页（`web/index.php`），无需数据库即可运行，适合任意 PHP 虚拟主机。

## 部署步骤

1. 将 `web/index.php` 上传到虚拟主机网站根目录
2. 修改文件顶部 3 个变量：

   ```php
   $notice      = "公告内容...";           // 官网公告
   $version     = "V2.2";                 // 当前版本号
   $downloadUrl = "https://你的域名/apk/slsdapp.apk"; // APK 下载地址
   ```

3. 将 `apk/slsdapp.apk` 上传到站点对应目录（保证 `$downloadUrl` 指向它）
4. 访问域名即看到官网页面，手机端自适应

## 对接数据库（可选）

如要公告、版本号由后台动态下发，替换 `$notice` / `$version` / `$downloadUrl` 为数据库读取：

```php
// 以 mysqli 为例
$conn = new mysqli("localhost", "用户", "密码", "数据库名");
$row  = $conn->query("SELECT content, version, url FROM config WHERE id=1")->fetch_assoc();

$notice      = $row['content'];
$version     = $row['version'];
$downloadUrl = $row['url'];
```

## 下载统计（可选）

如要记录每次下载的 IP，可对下载地址做一层跳转统计：

```php
// download.php
<?php
file_put_contents("downloads.log", date("Y-m-d H:i:s")." ".$_SERVER['REMOTE_ADDR'].PHP_EOL, FILE_APPEND);
header("Location: /apk/slsdapp.apk");
?>
```
